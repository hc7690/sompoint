const hre = require("hardhat");
require('dotenv').config();

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploying with", deployer.address);

  // Deploy SomPoint token
  const Token = await hre.ethers.getContractFactory("SomPoint");
  const token = await Token.deploy();
  await token.deployed();
  console.log("SomPoint deployed to", token.address);

  // Deploy ClickToEarn
  const rewardPerClick = hre.ethers.utils.parseUnits('1', 18); // 1 SMP per click
  const cooldown = 5; // seconds
  const topN = process.env.TOP_N ? parseInt(process.env.TOP_N) : 10;

  const Game = await hre.ethers.getContractFactory("ClickToEarn");
  const game = await Game.deploy(token.address, rewardPerClick, cooldown, topN);
  await game.deployed();
  console.log("ClickToEarn deployed to", game.address);

  // transfer token contract ownership to game so game can mint on claim
  await token.transferOwnership(game.address);
  console.log("Transferred token ownership to game contract");

  console.log("Deployment complete.");
  console.log("SomPoint token address:", token.address);
  console.log("ClickToEarn game address:", game.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
