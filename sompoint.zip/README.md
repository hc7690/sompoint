# SomPoint - Somnia Click-to-Earn (Testnet/Mainnet)

**SomPoint (SMP)** is a simple on-chain click-to-earn game built for the Somnia network.
This repo is prepared to run on Termux (Android arm64) with Node v22 and Hardhat 2.x compatibility.

## What it includes
- `contracts/SomPoint.sol` - ERC20 mintable token (owner can mint unlimited)
- `contracts/ClickToEarn.sol` - click-to-earn contract (records score, pending rewards, claim function)
- `scripts/deploy.js` - deploys token + game, transfers token ownership to game
- `frontend/` - simple UI to connect wallet, click, view points and claim
- `.env.example` - env vars for testnet & mainnet
- `hardhat.config.cjs` - networks for Somnia testnet & mainnet

## Quick start (Termux - Android)
1. Unzip project and enter folder:
```bash
unzip sompoint-ready.zip
cd sompoint
```

2. Create `.env` from example and fill your private key:
```bash
cp .env.example .env
# edit .env and set PRIVATE_KEY
```

3. Install dependencies (use legacy peer deps to avoid conflicts):
```bash
rm -rf node_modules package-lock.json
npm cache clean --force
pkg install nodejs-lts -y
npm install --legacy-peer-deps
```

4. Compile & deploy to Somnia Testnet:
```bash
npm run compile
npm run deploy:test
```

After deploy, script prints the SomPoint token address and ClickToEarn game address.
Copy the game address and update `frontend/app.js` -> `GAME_ADDRESS` then open `frontend/index.html` in a browser.

## Verify contract on Somnia Explorer
To verify source on Somnia Explorer (if supported):
1. Add your explorer API key to `.env`:
```
EXPLORER_API_KEY=your_api_key_here
```
2. Run Hardhat verify (example):
```bash
npx hardhat verify --network somniaTestnet <CONTRACT_ADDRESS> "<constructor_args_if_any>"
```

If automatic verify plugin not configured for Somnia, use the explorer's web verify form and paste the flattened source & compiler settings (Solidity 0.8.19, optimizer disabled or enabled as used).

## Frontend usage
1. Open `frontend/index.html` in a browser with MetaMask connected to Somnia Testnet.
2. Click **Connect Wallet**, then **Click to Earn** to accumulate pending SMP.
3. Press **Claim** to mint the pending SMP to your address (ClickToEarn contract mints tokens).

## Deployer Information
- Author: @hc7690
- Wallet Address: 0x322ae6ea7307c963d17af6942de772d0d5e140a1
- Token: SOMPOINT (SMP)
- Network: Somnia Testnet & Mainnet

## Notes & security
- SomPoint token is mintable by the game contract (contract ownership is transferred in deploy script). Use with care on mainnet.
- This project is for event/testing purposes. Do not use on mainnet without audits.

---
Happy hacking 🎃
