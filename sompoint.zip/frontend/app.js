// Replace GAME_ADDRESS with deployed ClickToEarn address
const GAME_ADDRESS = "REPLACE_GAME_ADDRESS";
const GAME_ABI = [
  "function click() external",
  "function claim() external",
  "function getTopPlayers() view returns (address[])",
  "function getTopScores() view returns (uint256[])",
  "function pending(address) view returns (uint256)",
  "function score(address) view returns (uint256)",
  "event Clicked(address indexed player, uint256 newScore)",
  "event Claimed(address indexed player, uint256 amount)"
];

let provider, signer, userAddr;

async function connect() {
  if (!window.ethereum) { alert('No wallet found'); return; }
  await window.ethereum.request({ method: 'eth_requestAccounts' });
  provider = new ethers.providers.Web3Provider(window.ethereum, 'any');
  signer = provider.getSigner();
  userAddr = await signer.getAddress();
  document.getElementById('addr').innerText = userAddr;
  loadStatus();
  loadLeaderboard();
}

async function callClick() {
  if (!signer) return alert('Connect wallet first');
  const contract = new ethers.Contract(GAME_ADDRESS, GAME_ABI, signer);
  const tx = await contract.click();
  document.getElementById('status').innerText = 'Tx sent: ' + tx.hash;
  await tx.wait();
  document.getElementById('status').innerText = 'Click confirmed';
  loadStatus();
  loadLeaderboard();
}

async function callClaim() {
  if (!signer) return alert('Connect wallet first');
  const contract = new ethers.Contract(GAME_ADDRESS, GAME_ABI, signer);
  const tx = await contract.claim();
  document.getElementById('status').innerText = 'Claim tx: ' + tx.hash;
  await tx.wait();
  document.getElementById('status').innerText = 'Claim confirmed';
  loadStatus();
  loadLeaderboard();
}

async function loadStatus() {
  if (!provider || !userAddr) return;
  const contract = new ethers.Contract(GAME_ADDRESS, GAME_ABI, provider);
  const pending = await contract.pending(userAddr);
  const points = await contract.score(userAddr);
  document.getElementById('points').innerText = points.toString();
  const pendingHuman = ethers.utils.formatUnits(pending, 18);
  document.getElementById('status').innerText = 'Pending to claim: ' + pendingHuman + ' SMP';
}

async function loadLeaderboard() {
  if (!provider) return;
  const contract = new ethers.Contract(GAME_ADDRESS, GAME_ABI, provider);
  const players = await contract.getTopPlayers();
  const scores = await contract.getTopScores();
  const ol = document.getElementById('leaders');
  ol.innerHTML = '';
  for (let i=0;i<players.length;i++){
    const li = document.createElement('li');
    li.innerText = players[i] + ' — ' + scores[i];
    ol.appendChild(li);
  }
}

window.addEventListener('load', ()=>{
  document.getElementById('connectBtn').onclick = connect;
  document.getElementById('clickBtn').onclick = callClick;
  document.getElementById('claimBtn').onclick = callClaim;
  loadLeaderboard();
});
