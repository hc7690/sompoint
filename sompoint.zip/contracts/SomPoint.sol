// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

contract SomPoint is ERC20, Ownable {
    constructor() ERC20("Somnia Point", "SMP") {
        // initial supply = 0, owner can mint unlimited
    }

    function mint(address to, uint256 amount) external onlyOwner {
        _mint(to, amount);
    }
}
