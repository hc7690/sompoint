// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "./SomPoint.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

contract ClickToEarn is Ownable {
    SomPoint public token;
    uint256 public rewardPerClick;
    uint256 public cooldownSeconds;

    mapping(address => uint256) public score;
    mapping(address => uint256) public lastClickAt;
    mapping(address => uint256) public pending; // pending tokens awaiting claim

    // leaderboard (top N)
    uint256 public topN;
    address[] public topPlayers;

    event Clicked(address indexed player, uint256 newScore);
    event Claimed(address indexed player, uint256 amount);

    constructor(address _token, uint256 _rewardPerClick, uint256 _cooldownSeconds, uint256 _topN) {
        token = SomPoint(_token);
        rewardPerClick = _rewardPerClick;
        cooldownSeconds = _cooldownSeconds;
        topN = _topN;
    }

    function click() external {
        require(block.timestamp - lastClickAt[msg.sender] >= cooldownSeconds, "Cooldown");
        lastClickAt[msg.sender] = block.timestamp;
        score[msg.sender] += 1;
        pending[msg.sender] += rewardPerClick;

        _maybeUpdateLeaderboard(msg.sender);

        emit Clicked(msg.sender, score[msg.sender]);
    }

    function claim() external {
        uint256 amt = pending[msg.sender];
        require(amt > 0, "No rewards");
        pending[msg.sender] = 0;
        // mint tokens directly to user (token is mintable by owner; this contract must be owner)
        token.mint(msg.sender, amt);
        emit Claimed(msg.sender, amt);
    }

    function _maybeUpdateLeaderboard(address player) internal {
        bool found = false;
        for (uint i = 0; i < topPlayers.length; i++) {
            if (topPlayers[i] == player) {
                found = true;
                break;
            }
        }
        if (!found) {
            topPlayers.push(player);
        }
        // simple sort by score desc
        for (uint i = 0; i < topPlayers.length; i++) {
            for (uint j = i + 1; j < topPlayers.length; j++) {
                if (score[topPlayers[j]] > score[topPlayers[i]]) {
                    address tmp = topPlayers[i];
                    topPlayers[i] = topPlayers[j];
                    topPlayers[j] = tmp;
                }
            }
        }
        if (topPlayers.length > topN) {
            while (topPlayers.length > topN) {
                topPlayers.pop();
            }
        }
    }

    function getTopPlayers() external view returns (address[] memory) {
        return topPlayers;
    }

    function getTopScores() external view returns (uint256[] memory) {
        uint256 len = topPlayers.length;
        uint256[] memory out = new uint256[](len);
        for (uint i = 0; i < len; i++) {
            out[i] = score[topPlayers[i]];
        }
        return out;
    }

    function setRewardPerClick(uint256 _r) external onlyOwner {
        rewardPerClick = _r;
    }

    function setCooldown(uint256 s) external onlyOwner {
        cooldownSeconds = s;
    }

    function setTopN(uint256 n) external onlyOwner {
        topN = n;
    }
}
