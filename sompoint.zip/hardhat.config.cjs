require("@nomiclabs/hardhat-ethers");
require('dotenv').config();

module.exports = {
  solidity: "0.8.19",
  networks: {
    somniaTestnet: {
      url: process.env.SOMNIA_TESTNET_RPC || "https://rpc.testnet.somnia.network",
      chainId: process.env.SOMNIA_TESTNET_CHAIN_ID ? parseInt(process.env.SOMNIA_TESTNET_CHAIN_ID) : 1111,
      accounts: process.env.PRIVATE_KEY ? [process.env.PRIVATE_KEY] : []
    },
    somniaMainnet: {
      url: process.env.SOMNIA_MAINNET_RPC || "https://rpc.somnia.network",
      chainId: process.env.SOMNIA_MAINNET_CHAIN_ID ? parseInt(process.env.SOMNIA_MAINNET_CHAIN_ID) : 719,
      accounts: process.env.PRIVATE_KEY ? [process.env.PRIVATE_KEY] : []
    }
  }
};
